// LAMBDA FUNCTION 2: Candidate Management API
// Handles: Candidate Registration, Admin Approval, Candidate Management
// Admin-focused endpoints for managing candidates

import AWS from 'aws-sdk';

const dynamodb = new AWS.DynamoDB.DocumentClient();

// Environment variables
const CANDIDATES_TABLE = process.env.CANDIDATES_TABLE || 'candidate_table';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
  'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,PUT,DELETE',
  'Access-Control-Allow-Credentials': false
};

// =============================================================================
// MAIN HANDLER - Candidate Management API
// =============================================================================
export const handler = async (event) => {
  console.log('Candidate Management API - Incoming request:', JSON.stringify(event, null, 2));

  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: ''
    };
  }

  try {
    const path = event.path || event.pathParameters?.proxy || '';
    const method = event.httpMethod;

    console.log(`Candidate Management API - Processing ${method} ${path}`);

    // Route requests to candidate management functions
    switch (path) {
      case '/health':
        return await healthCheck();

      case '/candidates':
        if (method === 'GET') return await getAllCandidates();
        if (method === 'POST') return await registerCandidate(event);
        break;

      case '/candidates/pending':
        if (method === 'GET') return await getPendingCandidates();
        break;

      case '/candidates/approve':
        if (method === 'POST') return await approveCandidate(event);
        break;

      case '/candidates/reject':
        if (method === 'POST') return await rejectCandidate(event);
        break;

      case '/admin/stats':
        if (method === 'GET') return await getAdminStats();
        break;

      default:
        return {
          statusCode: 404,
          headers: corsHeaders,
          body: JSON.stringify({
            error: 'Endpoint not found in Candidate Management API',
            path: path,
            availableEndpoints: ['/health', '/candidates', '/candidates/pending', '/candidates/approve', '/candidates/reject', '/admin/stats']
          })
        };
    }

    return {
      statusCode: 405,
      headers: corsHeaders,
      body: JSON.stringify({
        error: 'Method not allowed',
        method: method,
        path: path
      })
    };

  } catch (error) {
    console.error('Candidate Management API - Unhandled error:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: 'Internal server error',
        message: error.message,
        service: 'Candidate Management API'
      })
    };
  }
};

// =============================================================================
// HEALTH CHECK FUNCTION
// =============================================================================
async function healthCheck() {
  console.log('Candidate Management API - Health check requested');

  return {
    statusCode: 200,
    headers: corsHeaders,
    body: JSON.stringify({
      status: 'healthy',
      service: 'Candidate Management API',
      timestamp: new Date().toISOString(),
      version: '1.0.0',
      endpoints: ['/candidates', '/candidates/pending', '/candidates/approve', '/admin/stats'],
      environment: {
        candidatesTable: CANDIDATES_TABLE
      }
    })
  };
}

// =============================================================================
// GET ALL CANDIDATES FUNCTION - Admin view (all statuses)
// =============================================================================
async function getAllCandidates() {
  console.log('Candidate Management API - Getting all candidates (admin view)');

  try {
    const result = await dynamodb.scan({
      TableName: CANDIDATES_TABLE
    }).promise();

    // Group candidates by status
    const candidatesByStatus = {
      approved: [],
      pending: [],
      rejected: []
    };

    result.Items.forEach(candidate => {
      const status = candidate.status || 'pending';
      if (candidatesByStatus[status]) {
        candidatesByStatus[status].push(candidate);
      }
    });

    console.log(`Candidate Management API - Found ${result.Items.length} total candidates`);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        candidates: result.Items,
        candidatesByStatus: candidatesByStatus,
        totalCount: result.Items.length,
        statusCounts: {
          approved: candidatesByStatus.approved.length,
          pending: candidatesByStatus.pending.length,
          rejected: candidatesByStatus.rejected.length
        },
        timestamp: new Date().toISOString()
      })
    };

  } catch (error) {
    console.error('Candidate Management API - Error getting all candidates:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: 'Failed to retrieve candidates',
        message: error.message
      })
    };
  }
}

// =============================================================================
// GET PENDING CANDIDATES FUNCTION - For admin approval queue
// =============================================================================
async function getPendingCandidates() {
  console.log('Candidate Management API - Getting pending candidates');

  try {
    const result = await dynamodb.scan({
      TableName: CANDIDATES_TABLE,
      FilterExpression: '#status = :status',
      ExpressionAttributeNames: {
        '#status': 'status'
      },
      ExpressionAttributeValues: {
        ':status': 'pending'
      }
    }).promise();

    // Sort by registration date (oldest first)
    const pendingCandidates = result.Items.sort((a, b) =>
      new Date(a.registrationDate) - new Date(b.registrationDate)
    );

    console.log(`Candidate Management API - Found ${pendingCandidates.length} pending candidates`);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        pendingCandidates: pendingCandidates,
        count: pendingCandidates.length,
        timestamp: new Date().toISOString(),
        message: pendingCandidates.length === 0 ? 'No candidates pending approval' : `${pendingCandidates.length} candidates awaiting review`
      })
    };

  } catch (error) {
    console.error('Candidate Management API - Error getting pending candidates:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: 'Failed to retrieve pending candidates',
        message: error.message
      })
    };
  }
}

// =============================================================================
// REGISTER CANDIDATE FUNCTION - Student registration
// =============================================================================
async function registerCandidate(event) {
  console.log('Candidate Management API - Processing candidate registration');

  try {
    const candidateData = JSON.parse(event.body || '{}');
    console.log('Candidate Management API - Registration data received:', candidateData);

    const {
      name,
      email,
      description,
      platform,
      experience,
      studentId,
      phone
    } = candidateData;

    // Validate required fields
    const requiredFields = { name, email, description, platform, studentId };
    const missingFields = Object.entries(requiredFields)
      .filter(([, value]) => !value)
      .map(([key]) => key);

    if (missingFields.length > 0) {
      console.log('Candidate Management API - Missing required fields:', missingFields);
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({
          error: 'Missing required fields',
          missingFields: missingFields,
          requiredFields: ['name', 'email', 'description', 'platform', 'studentId']
        })
      };
    }

    // Check for duplicate email or student ID
    const existingCandidates = await dynamodb.scan({
      TableName: CANDIDATES_TABLE,
      FilterExpression: 'email = :email OR studentId = :studentId',
      ExpressionAttributeValues: {
        ':email': email.toLowerCase().trim(),
        ':studentId': studentId.trim()
      }
    }).promise();

    if (existingCandidates.Items.length > 0) {
      const duplicateField = existingCandidates.Items[0].email === email.toLowerCase().trim() ? 'email' : 'studentId';
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({
          error: `A candidate with this ${duplicateField} already exists`,
          duplicateField: duplicateField
        })
      };
    }

    // Generate unique candidate ID
    const timestamp = Date.now();
    const randomId = Math.random().toString(36).substr(2, 9);
    const candidateId = `candidate_${timestamp}_${randomId}`;

    console.log('Candidate Management API - Generated candidate ID:', candidateId);

    // Create candidate record
    const candidate = {
      id: candidateId,
      name: name.trim(),
      email: email.toLowerCase().trim(),
      description: description.trim(),
      platform: platform.trim(),
      experience: experience ? experience.trim() : '',
      studentId: studentId.trim(),
      phone: phone ? phone.trim() : '',
      status: 'pending',
      registrationDate: new Date().toISOString(),
      approvedDate: null,
      approvedBy: null,
      rejectedDate: null,
      rejectedBy: null,
      rejectionReason: null,
      votes: 0,
      metadata: {
        ipAddress: event.requestContext?.identity?.sourceIp || 'unknown',
        userAgent: event.headers?.['User-Agent'] || 'unknown',
        registrationSource: 'web'
      }
    };

    // Save to DynamoDB
    await dynamodb.put({
      TableName: CANDIDATES_TABLE,
      Item: candidate
    }).promise();

    console.log('Candidate Management API - Candidate registered successfully:', candidateId);

    return {
      statusCode: 201,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'Candidate registration submitted successfully',
        candidateId: candidateId,
        status: 'pending',
        nextSteps: [
          'Your application is under review by the election committee',
          'You will be notified via email about the approval status',
          'The review process typically takes 2-3 business days',
          'You can check your application status by contacting the election committee'
        ],
        estimatedReviewTime: '2-3 business days'
      })
    };

  } catch (error) {
    console.error('Candidate Management API - Error registering candidate:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: 'Failed to register candidate',
        message: error.message
      })
    };
  }
}

// =============================================================================
// APPROVE CANDIDATE FUNCTION - Admin approval
// =============================================================================
async function approveCandidate(event) {
  console.log('Candidate Management API - Processing candidate approval');

  try {
    const approvalData = JSON.parse(event.body || '{}');
    const { candidateId, adminId, notes } = approvalData;

    console.log('Candidate Management API - Approval request:', { candidateId, adminId });

    // Validate required fields
    if (!candidateId || !adminId) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({
          error: 'Missing required fields',
          required: ['candidateId', 'adminId']
        })
      };
    }

    // Update candidate status
    const updateParams = {
      TableName: CANDIDATES_TABLE,
      Key: { id: candidateId },
      UpdateExpression: 'SET #status = :status, approvedDate = :date, approvedBy = :admin, approvalNotes = :notes',
      ExpressionAttributeNames: {
        '#status': 'status'
      },
      ExpressionAttributeValues: {
        ':status': 'approved',
        ':date': new Date().toISOString(),
        ':admin': adminId,
        ':notes': notes || 'Approved by admin'
      },
      ReturnValues: 'ALL_NEW'
    };

    const result = await dynamodb.update(updateParams).promise();

    console.log(`Candidate Management API - Candidate ${candidateId} approved by ${adminId}`);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'Candidate approved successfully',
        candidate: result.Attributes,
        timestamp: new Date().toISOString(),
        action: 'approved'
      })
    };

  } catch (error) {
    console.error('Candidate Management API - Error approving candidate:', error);

    if (error.code === 'ResourceNotFoundException') {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({
          error: 'Candidate not found',
          candidateId: JSON.parse(event.body || '{}').candidateId
        })
      };
    }

    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: 'Failed to approve candidate',
        message: error.message
      })
    };
  }
}

// =============================================================================
// REJECT CANDIDATE FUNCTION - Admin rejection
// =============================================================================
async function rejectCandidate(event) {
  console.log('Candidate Management API - Processing candidate rejection');

  try {
    const rejectionData = JSON.parse(event.body || '{}');
    const { candidateId, adminId, reason } = rejectionData;

    console.log('Candidate Management API - Rejection request:', { candidateId, adminId, reason });

    // Validate required fields
    if (!candidateId || !adminId || !reason) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({
          error: 'Missing required fields',
          required: ['candidateId', 'adminId', 'reason']
        })
      };
    }

    // Update candidate status
    const updateParams = {
      TableName: CANDIDATES_TABLE,
      Key: { id: candidateId },
      UpdateExpression: 'SET #status = :status, rejectedDate = :date, rejectedBy = :admin, rejectionReason = :reason',
      ExpressionAttributeNames: {
        '#status': 'status'
      },
      ExpressionAttributeValues: {
        ':status': 'rejected',
        ':date': new Date().toISOString(),
        ':admin': adminId,
        ':reason': reason
      },
      ReturnValues: 'ALL_NEW'
    };

    const result = await dynamodb.update(updateParams).promise();

    console.log(`Candidate Management API - Candidate ${candidateId} rejected by ${adminId}`);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        message: 'Candidate rejected',
        candidate: result.Attributes,
        timestamp: new Date().toISOString(),
        action: 'rejected',
        reason: reason
      })
    };

  } catch (error) {
    console.error('Candidate Management API - Error rejecting candidate:', error);

    if (error.code === 'ResourceNotFoundException') {
      return {
        statusCode: 404,
        headers: corsHeaders,
        body: JSON.stringify({
          error: 'Candidate not found',
          candidateId: JSON.parse(event.body || '{}').candidateId
        })
      };
    }

    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: 'Failed to reject candidate',
        message: error.message
      })
    };
  }
}

// =============================================================================
// GET ADMIN STATS FUNCTION - Dashboard statistics
// =============================================================================
async function getAdminStats() {
  console.log('Candidate Management API - Getting admin statistics');

  try {
    // Get all candidates
    const candidatesResult = await dynamodb.scan({
      TableName: CANDIDATES_TABLE
    }).promise();

    // Calculate statistics
    const stats = {
      totalCandidates: candidatesResult.Items.length,
      approved: 0,
      pending: 0,
      rejected: 0,
      recentRegistrations: 0
    };

    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();

    candidatesResult.Items.forEach(candidate => {
      // Count by status
      switch (candidate.status) {
        case 'approved':
          stats.approved++;
          break;
        case 'pending':
          stats.pending++;
          break;
        case 'rejected':
          stats.rejected++;
          break;
      }

      // Count recent registrations (last 24 hours)
      if (candidate.registrationDate > oneDayAgo) {
        stats.recentRegistrations++;
      }
    });

    // Get recent candidates (last 5)
    const recentCandidates = candidatesResult.Items
      .sort((a, b) => new Date(b.registrationDate) - new Date(a.registrationDate))
      .slice(0, 5)
      .map(candidate => ({
        id: candidate.id,
        name: candidate.name,
        email: candidate.email,
        status: candidate.status,
        registrationDate: candidate.registrationDate
      }));

    console.log('Candidate Management API - Admin stats calculated:', stats);

    return {
      statusCode: 200,
      headers: corsHeaders,
      body: JSON.stringify({
        statistics: stats,
        recentCandidates: recentCandidates,
        timestamp: new Date().toISOString(),
        summary: {
          approvalRate: stats.totalCandidates > 0 ? ((stats.approved / stats.totalCandidates) * 100).toFixed(1) + '%' : '0%',
          pendingReview: stats.pending,
          needsAttention: stats.pending > 5 ? 'High volume of pending applications' : 'Normal processing volume'
        }
      })
    };

  } catch (error) {
    console.error('Candidate Management API - Error getting admin stats:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({
        error: 'Failed to get admin statistics',
        message: error.message
      })
    };
  }
}